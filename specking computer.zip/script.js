alert('⚠️ if you want change the speed of talking in the middle, first click on the stop and then change the speed and after that click to start over ⚠️')

const playButton = document.getElementById('play-button')
const pauseButton = document.getElementById('pause-button')
const stopButton = document.getElementById('stop-button')
const textInput = document.getElementById('text')
const speedInput = document.getElementById('speed')

playButton.addEventListener('click',()=>{
    playText(textInput.value);
})
pauseButton.addEventListener('click' , PauseText)
stopButton.addEventListener('click', StopText)

function playText(text) {
    if(speechSynthesis.paused && speechSynthesis.speaking){
        return speechSynthesis.resume()
    }
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = speedInput.value || 1
    utterance.addEventListener('end',() => {
        textInput.disabled = false
    })

    textInput.disabled = true
    speechSynthesis.speak(utterance)
}

function PauseText(){
    if(speechSynthesis.speaking) speechSynthesis.pause()
}

function StopText(){
    speechSynthesis.resume()
    speechSynthesis.cancel()
} 


// end speacking computer 

const inp = document.getElementById("search");
const btn = document.getElementById("btn");
const cont = document.querySelector(".content")


btn.addEventListener("click", loremGen)
cont.addEventListener("click",function(){
    navigator.clipboard.writeText(cont.textContent).then(() =>{
        alert("Text Copied successfully")
    })
})

async function loremGen(){
    try{
        if(inp.value === ""){
            alert("Required")
        }else{
            let res=await 
            fetch(`http://hipsum.co/api/?type=hipster-centric&sentences=${inp.value}`)
            let data=await res.json();
            cont.textContent=data;

        }
    }
    catch(e){
        console.log(e)
    }
}

